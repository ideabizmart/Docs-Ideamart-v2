"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Copy, Menu, Search, Home, Code, Check, AlertCircle, CheckCircle, XCircle, RefreshCw } from "lucide-react"

interface ServiceStatus {
  name: string
  status: "operational" | "degraded" | "outage" | "loading"
  lastUpdated: string
  description: string
}

interface Toast {
  message: string
  visible: boolean
  type: "success" | "error"
}

export default function OmniAIDocsPage() {
  const [selectedEndpoint, setSelectedEndpoint] = useState("chat-completion")
  const [activeTab, setActiveTab] = useState("overview")
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const [selectedLanguage, setSelectedLanguage] = useState("curl")
  const [toast, setToast] = useState<Toast>({ message: "", visible: false, type: "success" })
  const [serviceStatuses, setServiceStatuses] = useState<ServiceStatus[]>([
    { name: "OpenAI", status: "loading", lastUpdated: "", description: "Loading..." },
    { name: "Gemini", status: "loading", lastUpdated: "", description: "Loading..." },
    { name: "Claude", status: "loading", lastUpdated: "", description: "Loading..." },
  ])
  const searchModalRef = useRef<HTMLDivElement>(null)
  const [isRefreshing, setIsRefreshing] = useState(false)

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.key === "k") {
        e.preventDefault()
        setSearchOpen(true)
      }
      if (e.key === "Escape" && searchOpen) {
        setSearchOpen(false)
      }
    }

    const handleClickOutside = (e: MouseEvent) => {
      if (searchOpen && searchModalRef.current && !searchModalRef.current.contains(e.target as Node)) {
        setSearchOpen(false)
      }
    }

    document.addEventListener("keydown", handleKeyDown)
    document.addEventListener("mousedown", handleClickOutside)

    return () => {
      document.removeEventListener("keydown", handleKeyDown)
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [searchOpen])

  const fetchServiceStatus = async (isManualRefresh = false) => {
    if (isManualRefresh) {
      setIsRefreshing(true)
    }

    try {
      // Add cache-busting parameter to ensure fresh data
      const timestamp = new Date().getTime()
      
      const openaiResponse = await fetch(
        "/api/proxy-rss?url=" + encodeURIComponent("https://status.openai.com/feed.rss") + "&t=" + timestamp,
        { cache: 'no-cache' }
      )
      if (openaiResponse.ok) {
        const openaiText = await openaiResponse.text()
        const openaiStatus = parseRSSStatus(openaiText, "OpenAI")
        setServiceStatuses((prev) => prev.map((s) => (s.name === "OpenAI" ? openaiStatus : s)))
      }

      const claudeResponse = await fetch(
        "/api/proxy-rss?url=" + encodeURIComponent("https://status.claude.com/history.rss") + "&t=" + timestamp,
        { cache: 'no-cache' }
      )
      if (claudeResponse.ok) {
        const claudeText = await claudeResponse.text()
        const claudeStatus = parseRSSStatus(claudeText, "Claude")
        setServiceStatuses((prev) => prev.map((s) => (s.name === "Claude" ? claudeStatus : s)))
      }

      const geminiResponse = await fetch(
        "/api/proxy-rss?url=" + encodeURIComponent("https://status.cloud.google.com/en/feed.atom") + "&t=" + timestamp,
        { cache: 'no-cache' }
      )
      if (geminiResponse.ok) {
        const geminiText = await geminiResponse.text()
        const geminiStatus = parseRSSStatus(geminiText, "Gemini")
        setServiceStatuses((prev) => prev.map((s) => (s.name === "Gemini" ? geminiStatus : s)))
      }
    } catch (error) {
      console.error("Error fetching service status:", error)
      setServiceStatuses((prev) =>
        prev.map((s) => ({
          ...s,
          status: "operational" as const,
          description: "Status check unavailable",
        })),
      )
    } finally {
      if (isManualRefresh) {
        setIsRefreshing(false)
      }
    }
  }

  useEffect(() => {
    fetchServiceStatus()
    const interval = setInterval(fetchServiceStatus, 300000)
    return () => clearInterval(interval)
  }, [])

  const parseRSSStatus = (rssText: string, serviceName: string): ServiceStatus => {
    try {
      const parser = new DOMParser()
      const xmlDoc = parser.parseFromString(rssText, "text/xml")
      
      // Handle both RSS (item) and Atom (entry) formats
      let items = xmlDoc.getElementsByTagName("item")
      let isAtomFeed = false
      
      if (items.length === 0) {
        items = xmlDoc.getElementsByTagName("entry")
        isAtomFeed = true
      }

      if (items.length > 0) {
        const latestItem = items[0]
        let title = ""
        let pubDate = ""
        let description = ""

        if (isAtomFeed) {
          // Atom feed format (Google Cloud)
          title = latestItem.getElementsByTagName("title")[0]?.textContent || ""
          const rawDate = latestItem.getElementsByTagName("updated")[0]?.textContent || ""
          // Convert to ISO format for consistency
          pubDate = rawDate ? new Date(rawDate).toISOString() : ""
          console.log(`[${serviceName}] Raw date:`, rawDate, "Parsed date:", pubDate)
          const content = latestItem.getElementsByTagName("content")[0]?.textContent || ""
          const summary = latestItem.getElementsByTagName("summary")[0]?.textContent || ""
          description = content || summary
        } else {
          // RSS format (OpenAI, Claude)
          title = latestItem.getElementsByTagName("title")[0]?.textContent || ""
          const rawDate = latestItem.getElementsByTagName("pubDate")[0]?.textContent || ""
          // Convert to ISO format for consistency
          pubDate = rawDate ? new Date(rawDate).toISOString() : ""
          console.log(`[${serviceName}] Raw date:`, rawDate, "Parsed date:", pubDate)
          description = latestItem.getElementsByTagName("description")[0]?.textContent || ""
        }

        let status: "operational" | "degraded" | "outage" = "operational"

        // Check if the incident is resolved
        const isResolved = description.toLowerCase().includes("resolved") || 
                          description.toLowerCase().includes("this incident has been resolved") ||
                          title.toLowerCase().includes("resolved")

        if (isResolved) {
          status = "operational"
        } else if (
          title.toLowerCase().includes("outage") ||
          title.toLowerCase().includes("down") ||
          description.toLowerCase().includes("outage") ||
          description.toLowerCase().includes("down") ||
          description.toLowerCase().includes("unavailable")
        ) {
          status = "outage"
        } else if (
          title.toLowerCase().includes("degraded") ||
          title.toLowerCase().includes("issue") ||
          title.toLowerCase().includes("elevated errors") ||
          title.toLowerCase().includes("investigating") ||
          title.toLowerCase().includes("monitoring") ||
          description.toLowerCase().includes("degraded") ||
          description.toLowerCase().includes("issue") ||
          description.toLowerCase().includes("elevated errors") ||
          description.toLowerCase().includes("investigating") ||
          description.toLowerCase().includes("monitoring")
        ) {
          status = "degraded"
        }

        // For resolved incidents, show operational status
        let displayDescription = title || "All systems operational"
        if (isResolved) {
          displayDescription = "All systems operational"
          status = "operational"
        }

        return {
          name: serviceName,
          status,
          lastUpdated: pubDate,
          description: displayDescription,
        }
      }
    } catch (error) {
      console.error(`Error parsing RSS for ${serviceName}:`, error)
    }

    return {
      name: serviceName,
      status: "operational",
      lastUpdated: new Date().toISOString(),
      description: "All systems operational",
    }
  }

  const getStatusIcon = (status: ServiceStatus["status"]) => {
    switch (status) {
      case "operational":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case "degraded":
        return <AlertCircle className="h-5 w-5 text-yellow-500" />
      case "outage":
        return <XCircle className="h-5 w-5 text-red-500" />
      default:
        return <div className="h-5 w-5 bg-gray-300 rounded-full animate-pulse" />
    }
  }

  const getStatusColor = (status: ServiceStatus["status"]) => {
    switch (status) {
      case "operational":
        return "border-green-200 bg-green-50"
      case "degraded":
        return "border-yellow-200 bg-yellow-50"
      case "outage":
        return "border-red-200 bg-red-50"
      default:
        return "border-gray-200 bg-gray-50"
    }
  }

  const copyToClipboard = (text: string, type = "content") => {
    navigator.clipboard
      .writeText(text)
      .then(() => {
        setToast({ message: `${type} copied to clipboard!`, visible: true, type: "success" })

        setTimeout(() => {
          setToast((prev) => ({ ...prev, visible: false }))
        }, 5000)
      })
      .catch(() => {
        setToast({ message: "Failed to copy to clipboard", visible: true, type: "error" })
        setTimeout(() => {
          setToast((prev) => ({ ...prev, visible: false }))
        }, 5000)
      })
  }

  const getCodeExample = (language: string) => {
    if (selectedEndpoint === "create-image") {
    if (language === "python") {
      return `Coming soon`
      }

      return `curl https://api.ideamart.io/omniai/api/v1/images/generations \\
  -H "Content-Type: application/json" \\
  -H "Authorization: app_1dd4f39c.8bf5e7f2236a4e0caa8780d8313b098d" \\
  -d '{
    "model": "gpt-image-1",
    "prompt": "a red apple",
    "n": 1,
    "size": "1024x1024",
    "quality": "low"
  }'`
    }

    if (language === "python") {
      return `Coming soon`
    }

    return `curl -X POST https://api.ideamart.io/omniai/api/v1/chat/completions \\
  -H "Content-Type: application/json" \\
  -H "Authorization: app_1dd4f39c.8bf5e7f2236a4e0caa8780d8313b098d" \\
  -d '{
    "model": "gpt-4o-mini",
    "messages": [
      {
        "role": "system",
        "content": [
          {
            "type": "text",
            "text": "Act as a friendly English-speaking conversation partner. Start a casual conversation with me about anything."
          }
        ]
      },
      {
        "role": "user",
        "content": [
          {
            "type": "text",
            "text": "Explain megapixels in a picture "
          }
        ]
      }
    ],
    "response_format": {
      "type": "text"
    }
  }'`
  }

  const getResponseExample = (language: string) => {
    if (selectedEndpoint === "create-image") {
      if (language === "python") {
        return `Coming soon`
      }
      return `{
  "created": 1767763326,
  "background": "opaque",
  "data": [
    {
      "b64_json": "[Base 64 String]"
    }
  ],
  "output_format": "png",
  "quality": "low",
  "size": "1024x1024",
  "usage": {
    "input_tokens": 9,
    "input_tokens_details": {
      "image_tokens": 0,
      "text_tokens": 9
    },
    "output_tokens": 272,
    "total_tokens": 281
  }
}`
    }

    if (language === "python") {
      return `Coming soon`
    }

    return `{
  "id": "chatcmpl-B9MBs8CjcvOU2jLn4n570S5qMJKcT",
  "object": "chat.completion",
  "created": 1741569952,
  "model": "gpt-4o-mini",
  "choices": [
    {
      "index": 0,
      "message": {
        "role": "assistant",
        "content": "Hello! How can I assist you today?",
        "refusal": null,
        "annotations": []
      },
      "logprobs": null,
      "finish_reason": "stop"
    }
  ],
  "usage": {
    "prompt_tokens": 19,
    "completion_tokens": 10,
    "total_tokens": 29,
    "prompt_tokens_details": {
      "cached_tokens": 0,
      "audio_tokens": 0
    },
    "completion_tokens_details": {
      "reasoning_tokens": 0,
      "audio_tokens": 0,
      "accepted_prediction_tokens": 0,
      "rejected_prediction_tokens": 0
    }
  },
  "service_tier": "default"
}`
  }

  const endpoints = [
    {
      id: "chat-completion",
      title: "Create chat completion",
      method: "POST",
      path: "/v1/chat/completions",
      description: "Creates a model response for the given chat conversation.",
      category: "Chat",
    },
    {
      id: "create-image",
      title: "Create image",
      method: "POST",
      path: "/v1/images/generations",
      description: "Creates an image given a text prompt.",
      category: "Images",
    },
    {
      id: "error-codes",
      title: "Error Codes",
      method: "GET",
      path: "/docs/errors",
      description: "Comprehensive list of error codes and their meanings.",
      category: "Reference",
    },
  ]

  const sidebarItems = [
    { icon: Home, label: "Overview", href: "#", id: "overview" },
    { icon: Code, label: "API Reference", href: "#", id: "api-reference" },
  ]

  const currentEndpoint = endpoints.find((e) => e.id === selectedEndpoint)

  const renderContent = () => {
    if (activeTab === "overview") {
      return (
        <div className="p-4 md:p-6 space-y-6">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-black mb-4">Welcome to OmniAI</h1>
            <p className="text-black text-base md:text-lg mb-6">
              OmniAI is a powerful artificial intelligence platform that provides state-of-the-art language models and
              AI capabilities through a simple, developer-friendly API.
            </p>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg md:text-xl font-semibold text-black">Service Status</h2>
              <button
                onClick={() => fetchServiceStatus(true)}
                disabled={isRefreshing}
                className="flex items-center gap-2 px-3 py-1.5 text-sm bg-transparent border border-gray-300 rounded-md hover:bg-white hover:text-[#e81e5a] hover:border-[#e81e5a] transition-colors disabled:opacity-50 disabled:cursor-not-allowed text-pink-700"
              >
                <RefreshCw className={`h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
                {isRefreshing ? "Refreshing..." : "Refresh"}
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {serviceStatuses.map((service) => {
                const getStatusPageUrl = (serviceName: string) => {
                  switch (serviceName) {
                    case "Claude":
                      return "https://status.claude.com/"
                    case "OpenAI":
                      return "https://status.openai.com/"
                    case "Gemini":
                      return "https://aistudio.google.com/status"
                    default:
                      return "#"
                  }
                }

                return (
                  <div key={service.name} className={`border rounded-lg p-4 ${getStatusColor(service.status)}`}>
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-black">{service.name}</h3>
                      {getStatusIcon(service.status)}
                    </div>
                    <p className="text-sm text-black capitalize mb-1">{service.status}</p>
                    <p className="text-xs text-gray-600 truncate">{service.description}</p>
                    {service.lastUpdated && (
                      <p className="text-xs text-gray-500 mt-2">
                        Updated: {new Date(service.lastUpdated).toLocaleDateString()}
                      </p>
                    )}
                    <div className="mt-3 pt-2 border-t border-gray-200">
                      <a
                        href={getStatusPageUrl(service.name)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs text-blue-600 hover:text-blue-800 hover:underline transition-colors"
                      >
                        View Status Page →
                      </a>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <h2 className="text-lg md:text-xl font-semibold text-black mb-3">Getting Started</h2>
              <p className="text-black mb-4">
                To get started with OmniAI, you'll need to obtain an API key and make your first API call. Our platform
                supports various AI models for different use cases including chat completions, text generation, and
                embeddings.
              </p>
              <ul className="list-disc list-inside space-y-2 text-black">
                <li>Sign up for an OmniAI account</li>
                <li>Generate your API key from the dashboard</li>
                <li>Make your first API call</li>
                <li>Explore our comprehensive documentation</li>
              </ul>
            </div>

            <div>
              <h2 className="text-lg md:text-xl font-semibold text-black mb-3">Key Features</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="border border-gray-200 rounded-lg p-4 bg-white">
                  <h3 className="font-semibold text-black mb-2">Chat Completions</h3>
                  <p className="text-black text-sm">Generate conversational responses with our advanced chat models.</p>
                </div>
                <div className="border border-gray-200 rounded-lg p-4 bg-white">
                  <h3 className="font-semibold text-black mb-2">Text Generation</h3>
                  <p className="text-black text-sm">Create high-quality text content for various applications.</p>
                </div>
                <div className="border border-gray-200 rounded-lg p-4 bg-white">
                  <h3 className="font-semibold text-black mb-2">Embeddings</h3>
                  <p className="text-black text-sm">
                    Convert text into numerical representations for semantic search and analysis.
                  </p>
                </div>
                <div className="border border-gray-200 rounded-lg p-4 bg-white">
                  <h3 className="font-semibold text-black mb-2">Scalable Infrastructure</h3>
                  <p className="text-black text-sm">
                    Built for enterprise-scale applications with high availability and performance.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )
    }

    if (selectedEndpoint === "create-image") {
      return (
        <div className="p-4 md:p-6 space-y-6">
          <div>
            <div className="flex items-center flex-wrap gap-2 mb-2">
              <Badge variant="secondary" className="text-xs font-mono">
                POST
              </Badge>
              <code className="text-xs md:text-sm font-mono text-black break-all">https://api.ideamart.io/omniai/api/v1/images/generations</code>
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-black mb-2">Create image</h1>
            <p className="text-black text-base md:text-lg">
              Creates an image given a text prompt.
            </p>
          </div>

          <div className="space-y-6">
            <div>
              <h2 className="text-lg md:text-xl font-semibold text-black mb-4">Request body</h2>
              <div className="space-y-4">
                {/* prompt parameter */}
                <div className="border border-gray-200 rounded-lg p-3 md:p-4 bg-white">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center flex-wrap gap-2">
                      <code className="text-xs md:text-sm font-mono text-black">prompt</code>
                      <Badge variant="outline" className="text-xs text-black">
                        string
                      </Badge>
                      <Badge variant="destructive" className="text-xs">
                        Required
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    A text description of the desired image(s). The maximum length is 32000 characters for GPT Image 1.
                  </p>
                </div>

                {/* background parameter */}
                <div className="border border-gray-200 rounded-lg p-4 bg-white">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black">background</code>
                      <Badge variant="outline" className="text-xs text-black">
                        string or null
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        Optional
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    Allows to set transparency for the background of the generated image(s). This parameter is supported for GPT Image 1. Must be one of <code className="bg-gray-100 px-1 rounded">transparent</code>, <code className="bg-gray-100 px-1 rounded">opaque</code> or <code className="bg-gray-100 px-1 rounded">auto</code> (default value). When auto is used, the model will automatically determine the best background for the image. If transparent, the output format needs to support transparency, so it should be set to either png (default value) or webp.
                  </p>
                  <p className="text-xs text-gray-500 mt-2">Defaults to: auto</p>
                </div>

                {/* model parameter */}
                <div className="border border-gray-200 rounded-lg p-4 bg-white">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black">model</code>
                      <Badge variant="outline" className="text-xs text-black">
                        string
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        Optional
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    The model to use for image generation. Use <code className="bg-gray-100 px-1 rounded">gpt-image-1</code> for GPT Image 1.
                  </p>
                  <p className="text-xs text-gray-500 mt-2">Defaults to: gpt-image-1</p>
                </div>

                {/* moderation parameter */}
                <div className="border border-gray-200 rounded-lg p-4 bg-white">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black">moderation</code>
                      <Badge variant="outline" className="text-xs text-black">
                        string or null
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        Optional
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    Control the content-moderation level for images generated by GPT Image 1. Must be either <code className="bg-gray-100 px-1 rounded">low</code> for less restrictive filtering or <code className="bg-gray-100 px-1 rounded">auto</code> (default value).
                  </p>
                  <p className="text-xs text-gray-500 mt-2">Defaults to: auto</p>
                </div>

                {/* n parameter */}
                <div className="border border-gray-200 rounded-lg p-4 bg-white">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black">n</code>
                      <Badge variant="outline" className="text-xs text-black">
                        integer or null
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        Optional
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    The number of images to generate. Must be between 1 and 10.
                  </p>
                  <p className="text-xs text-gray-500 mt-2">Defaults to: 1</p>
                </div>

                {/* output_compression parameter */}
                <div className="border border-gray-200 rounded-lg p-4 bg-white">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black">output_compression</code>
                      <Badge variant="outline" className="text-xs text-black">
                        integer or null
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        Optional
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    The compression level (0-100%) for the generated images. This parameter is supported for GPT Image 1 with the webp or jpeg output formats, and defaults to 100.
                  </p>
                  <p className="text-xs text-gray-500 mt-2">Defaults to: 100</p>
                </div>

                {/* output_format parameter */}
                <div className="border border-gray-200 rounded-lg p-4 bg-white">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black">output_format</code>
                      <Badge variant="outline" className="text-xs text-black">
                        string or null
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        Optional
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    The format in which the generated images are returned. This parameter is supported for GPT Image 1. Must be one of <code className="bg-gray-100 px-1 rounded">png</code>, <code className="bg-gray-100 px-1 rounded">jpeg</code>, or <code className="bg-gray-100 px-1 rounded">webp</code>.
                  </p>
                  <p className="text-xs text-gray-500 mt-2">Defaults to: png</p>
                </div>

                {/* partial_images parameter */}
                <div className="border border-gray-200 rounded-lg p-4 bg-white">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black">partial_images</code>
                      <Badge variant="outline" className="text-xs text-black">
                        integer
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        Optional
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    The number of partial images to generate. This parameter is used for streaming responses that return partial images. Value must be between 0 and 3. When set to 0, the response will be a single image sent in one streaming event. Note that the final image may be sent before the full number of partial images are generated if the full image is generated more quickly.
                  </p>
                  <p className="text-xs text-gray-500 mt-2">Defaults to: 0</p>
                </div>

                {/* quality parameter */}
                <div className="border border-gray-200 rounded-lg p-4 bg-white">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black">quality</code>
                      <Badge variant="outline" className="text-xs text-black">
                        string or null
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        Optional
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    The quality of the image that will be generated. <code className="bg-gray-100 px-1 rounded">auto</code> (default value) will automatically select the best quality. <code className="bg-gray-100 px-1 rounded">high</code>, <code className="bg-gray-100 px-1 rounded">medium</code> and <code className="bg-gray-100 px-1 rounded">low</code> are supported for GPT Image 1.
                  </p>
                  <p className="text-xs text-gray-500 mt-2">Defaults to: auto</p>
                </div>

                {/* response_format parameter */}
                <div className="border border-gray-200 rounded-lg p-4 bg-white">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black">response_format</code>
                      <Badge variant="outline" className="text-xs text-black">
                        string or null
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        Optional
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    The format in which generated images are returned. GPT Image 1 always returns base64-encoded images (<code className="bg-gray-100 px-1 rounded">b64_json</code>).
                  </p>
                  <p className="text-xs text-gray-500 mt-2">Defaults to: url</p>
                </div>

                {/* size parameter */}
                <div className="border border-gray-200 rounded-lg p-4 bg-white">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black">size</code>
                      <Badge variant="outline" className="text-xs text-black">
                        string or null
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        Optional
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    The size of the generated images. Must be one of <code className="bg-gray-100 px-1 rounded">1024x1024</code>, <code className="bg-gray-100 px-1 rounded">1536x1024</code> (landscape), <code className="bg-gray-100 px-1 rounded">1024x1536</code> (portrait), or <code className="bg-gray-100 px-1 rounded">auto</code> (default value) for GPT Image 1.
                  </p>
                  <p className="text-xs text-gray-500 mt-2">Defaults to: auto</p>
                </div>

                {/* stream parameter */}
                <div className="border border-gray-200 rounded-lg p-4 bg-white">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black">stream</code>
                      <Badge variant="outline" className="text-xs text-black">
                        boolean or null
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        Optional
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    Generate the image in streaming mode. Defaults to false. See the Image generation guide for more information. This parameter is supported for GPT Image 1.
                  </p>
                  <p className="text-xs text-gray-500 mt-2">Defaults to: false</p>
                </div>

                {/* style parameter */}
                <div className="border border-gray-200 rounded-lg p-4 bg-white">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black">style</code>
                      <Badge variant="outline" className="text-xs text-black">
                        string or null
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        Optional
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    The style of the generated images. Must be one of <code className="bg-gray-100 px-1 rounded">vivid</code> or <code className="bg-gray-100 px-1 rounded">natural</code>. Vivid causes the model to lean towards generating hyper-real and dramatic images. Natural causes the model to produce more natural, less hyper-real looking images.
                  </p>
                  <p className="text-xs text-gray-500 mt-2">Defaults to: vivid</p>
                </div>

                {/* user parameter */}
                <div className="border border-gray-200 rounded-lg p-4 bg-white">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black">user</code>
                      <Badge variant="outline" className="text-xs text-black">
                        string
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        Optional
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    A unique identifier representing your end-user, which can help OpenAI to monitor and detect abuse.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )
    }

    if (selectedEndpoint === "error-codes") {
      return (
        <div className="p-4 md:p-6 space-y-6">
          <div>
            <div className="flex items-center space-x-2 mb-2">
              <Badge variant="secondary" className="text-xs font-mono">
                REFERENCE
              </Badge>
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-black mb-2">Error Codes</h1>
            <p className="text-black text-lg">
              Comprehensive documentation of all error codes and messages that can be generated by the OmniAI API
              Gateway.
            </p>
          </div>

          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-semibold text-black mb-4">Error Response Structure</h2>
              <p className="text-black mb-4">All errors follow this consistent JSON structure:</p>
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                <pre className="text-sm font-mono text-black overflow-x-auto">
                  {`{
  "error": {
    "message": "Human-readable error message",
    "type": "Error type or code",
    "param": "Parameter name that caused the error (if applicable)",
    "code": "Error code (for webhook errors)",
    "additional_data": {
      "key": "value"
    }
  }
}`}
                </pre>
              </div>
            </div>

            <div>
              <h2 className="text-lg md:text-xl font-semibold text-black mb-4">HTTP Status Codes</h2>
              <div className="space-y-3">
                <div className="border border-red-200 bg-red-50 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black bg-red-100 px-2 py-1 rounded">400</code>
                      <Badge variant="outline" className="text-xs text-red-700 border-red-300">
                        Bad Request
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    Invalid request format or malformed request payload. Check your request body and ensure all required
                    fields are provided with valid values.
                  </p>
                  <p className="text-xs text-red-600">
                    Common causes: Invalid JSON, missing required fields, invalid parameter values
                  </p>
                </div>

                <div className="border border-red-200 bg-red-50 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black bg-red-100 px-2 py-1 rounded">401</code>
                      <Badge variant="outline" className="text-xs text-red-700 border-red-300">
                        Unauthorized
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    Authentication failed. Your API key is either missing, invalid, or expired. Ensure you're including
                    a valid API key in the Authorization header.
                  </p>
                  <p className="text-xs text-red-600">Check your API key format: Bearer YOUR_API_KEY</p>
                </div>

                <div className="border border-yellow-200 bg-yellow-50 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black bg-yellow-100 px-2 py-1 rounded">402</code>
                      <Badge variant="outline" className="text-xs text-yellow-700 border-yellow-300">
                        Payment Required
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    Insufficient token balance. Please add more tokens to your account to continue using the API.
                  </p>
                  <p className="text-xs text-yellow-600">Check your account balance and add credits if needed</p>
                </div>

                <div className="border border-red-200 bg-red-50 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black bg-red-100 px-2 py-1 rounded">403</code>
                      <Badge variant="outline" className="text-xs text-red-700 border-red-300">
                        Forbidden
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    You don't have permission to access this resource. This may be due to insufficient account
                    permissions or trying to access a restricted model.
                  </p>
                  <p className="text-xs text-red-600">Contact support if you believe you should have access</p>
                </div>

                <div className="border border-gray-200 bg-gray-50 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black bg-gray-100 px-2 py-1 rounded">404</code>
                      <Badge variant="outline" className="text-xs text-gray-700 border-gray-300">
                        Not Found
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    Project not found with the provided API key. Verify that your API key is correct and the project
                    exists.
                  </p>
                  <p className="text-xs text-gray-600">Double-check your API key format: keyId.keyValue</p>
                </div>

                <div className="border border-yellow-200 bg-yellow-50 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black bg-yellow-100 px-2 py-1 rounded">429</code>
                      <Badge variant="outline" className="text-xs text-yellow-700 border-yellow-300">
                        Too Many Requests
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    Rate limit exceeded or token quota exceeded. Please wait before making additional requests or check
                    your token balance.
                  </p>
                  <p className="text-xs text-yellow-600">
                    Rate limits reset every minute. Check the Retry-After header
                  </p>
                </div>

                <div className="border border-red-200 bg-red-50 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black bg-red-100 px-2 py-1 rounded">500</code>
                      <Badge variant="outline" className="text-xs text-red-700 border-red-300">
                        Internal Server Error
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    An unexpected error occurred on our servers. Please try again later. If the problem persists,
                    contact our support team.
                  </p>
                  <p className="text-xs text-red-600">Our team is automatically notified of server errors</p>
                </div>

                <div className="border border-red-200 bg-red-50 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black bg-red-100 px-2 py-1 rounded">502</code>
                      <Badge variant="outline" className="text-xs text-red-700 border-red-300">
                        Bad Gateway
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    Failed to forward request to the LLM provider. This may be due to provider downtime or connectivity
                    issues.
                  </p>
                  <p className="text-xs text-red-600">Try again in a few moments or check provider status</p>
                </div>

                <div className="border border-red-200 bg-red-50 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black bg-red-100 px-2 py-1 rounded">503</code>
                      <Badge variant="outline" className="text-xs text-red-700 border-red-300">
                        Service Unavailable
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    The service is temporarily unavailable due to maintenance or high load. Please try again in a few
                    moments.
                  </p>
                  <p className="text-xs text-red-600">Check our status page for current service status</p>
                </div>
              </div>
            </div>

            <div>
              <h2 className="text-lg md:text-xl font-semibold text-black mb-4">Specific Error Codes</h2>
              <div className="space-y-3">
                <div className="border border-gray-200 bg-white rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black bg-gray-100 px-2 py-1 rounded">
                        PROJECT_NOT_FOUND
                      </code>
                      <Badge variant="outline" className="text-xs text-black">
                        404
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    Project not found with API key. The provided API key doesn't match any existing project.
                  </p>
                </div>

                <div className="border border-gray-200 bg-white rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black bg-gray-100 px-2 py-1 rounded">
                        PROJECT_INACTIVE
                      </code>
                      <Badge variant="outline" className="text-xs text-black">
                        403
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    Project is not active. The project exists but its status is not ACTIVE.
                  </p>
                </div>

                <div className="border border-gray-200 bg-white rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black bg-gray-100 px-2 py-1 rounded">
                        INVALID_LLM_CONFIG
                      </code>
                      <Badge variant="outline" className="text-xs text-black">
                        400
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    Invalid LLM model. The specified model is not configured or allowed for your project.
                  </p>
                </div>

                <div className="border border-gray-200 bg-white rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black bg-gray-100 px-2 py-1 rounded">
                        RATE_LIMIT_EXCEEDED
                      </code>
                      <Badge variant="outline" className="text-xs text-black">
                        429
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    Rate limit exceeded. Please try again later. Your project has exceeded the allowed number of
                    requests per time period.
                  </p>
                </div>

                <div className="border border-gray-200 bg-white rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black bg-gray-100 px-2 py-1 rounded">
                        TOKEN_QUOTA_EXCEEDED
                      </code>
                      <Badge variant="outline" className="text-xs text-black">
                        429
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    Token quota exceeded. Please check your token balance. Your project has used up its allocated token
                    quota.
                  </p>
                </div>

                <div className="border border-gray-200 bg-white rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black bg-gray-100 px-2 py-1 rounded">
                        INSUFFICIENT_BALANCE
                      </code>
                      <Badge variant="outline" className="text-xs text-black">
                        402
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    Insufficient token balance. Please add more tokens to your account. Your current balance is too low
                    to process the request.
                  </p>
                </div>

                <div className="border border-gray-200 bg-white rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <code className="text-sm font-mono text-black bg-gray-100 px-2 py-1 rounded">
                        FORWARDING_FAILED
                      </code>
                      <Badge variant="outline" className="text-xs text-black">
                        502
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-black mb-2">
                    Failed to forward webhook request. The request to the LLM provider failed due to connectivity or
                    provider issues.
                  </p>
                </div>
              </div>
            </div>

            <div>
              <h2 className="text-xl font-semibold text-black mb-4">Best Practices</h2>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h3 className="font-semibold text-black mb-2">For API Consumers</h3>
                <ul className="list-disc list-inside space-y-1 text-sm text-black">
                  <li>Always check the HTTP status code in addition to the error message</li>
                  <li>Handle rate limiting errors by implementing exponential backoff</li>
                  <li>Validate API keys before making requests</li>
                  <li>Check token balance proactively to avoid quota errors</li>
                  <li>Implement proper error logging for debugging</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )
    }

    return (
      <div className="p-4 md:p-6 space-y-6">
        <div>
          <div className="flex items-center flex-wrap gap-2 mb-2">
            <Badge variant="secondary" className="text-xs font-mono">
              {currentEndpoint?.method}
            </Badge>
            <code className="text-xs md:text-sm font-mono text-gray-600 break-all">
              {selectedEndpoint === "chat-completion" 
                ? "https://api.ideamart.io/omniai/api/v1/chat/completions"
                : selectedEndpoint === "create-image"
                ? "https://api.ideamart.io/omniai/api/v1/images/generations"
                : currentEndpoint?.path}
            </code>
          </div>
          <h1 className="text-2xl md:text-3xl font-bold text-black mb-2">{currentEndpoint?.title}</h1>
          <p className="text-black text-base md:text-lg">{currentEndpoint?.description}</p>
        </div>

        <div className="space-y-4">
          {selectedEndpoint === "chat-completion" && (
            <>
              <p className="text-sm text-black">
                Starting a new project? We recommend trying Responses to take advantage of the latest OmniAI platform
                features. Compare{" "}
                <a href="#" className="text-blue-600 hover:underline">
                  Chat Completions with Responses
                </a>
                .
              </p>

              <p className="text-black">
                Creates a model response for the given chat conversation. Learn more in the{" "}
                <a href="#" className="text-blue-600 hover:underline">
                  text generation
                </a>
                ,{" "}
                <a href="#" className="text-blue-600 hover:underline">
                  vision
                </a>
                , and{" "}
                <a href="#" className="text-blue-600 hover:underline">
                  audio
                </a>{" "}
                guides.
              </p>

              <p className="text-sm text-black">
                Parameter support can differ depending on the model used to generate the response. Different models have different capabilities and supported features.
              </p>
            </>
          )}
        </div>

        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-semibold text-black mb-4">Request body</h2>

            <div className="space-y-4">
              {selectedEndpoint === "chat-completion" && (
                <div className="space-y-4">
                  <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">messages</code>
                        <Badge variant="outline" className="text-xs font-mono text-black">
                          array
                        </Badge>
                        <Badge variant="destructive" className="text-xs">
                          Required
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      A list of messages comprising the conversation so far. Depending on the{" "}
                      <a href="#" className="text-blue-600 hover:underline">
                        model
                      </a>{" "}
                      you use, different message types (modalities) are supported, like text, images, and audio.
                    </p>
                    <div className="mt-3 space-y-3">
                      <div className="border-l-2 border-blue-200 pl-3">
                        <h4 className="text-sm font-semibold text-black mb-1">Developer message</h4>
                        <p className="text-xs text-gray-600 mb-2">Developer-provided instructions that the model should follow, regardless of messages sent by the user. Developer messages are used to provide system-level instructions.</p>
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <code className="text-xs font-mono bg-gray-100 px-1 py-0.5 rounded text-black">content</code>
                            <Badge variant="outline" className="text-xs text-black">string or array</Badge>
                            <Badge variant="destructive" className="text-xs">Required</Badge>
                          </div>
                          <p className="text-xs text-gray-600 ml-2">The contents of the developer message.</p>
                          <div className="flex items-center space-x-2">
                            <code className="text-xs font-mono bg-gray-100 px-1 py-0.5 rounded text-black">role</code>
                            <Badge variant="outline" className="text-xs text-black">string</Badge>
                            <Badge variant="destructive" className="text-xs">Required</Badge>
                          </div>
                          <p className="text-xs text-gray-600 ml-2">The role of the messages author, in this case developer.</p>
                          <div className="flex items-center space-x-2">
                            <code className="text-xs font-mono bg-gray-100 px-1 py-0.5 rounded text-black">name</code>
                            <Badge variant="outline" className="text-xs text-black">string</Badge>
                            <Badge variant="secondary" className="text-xs">Optional</Badge>
                          </div>
                          <p className="text-xs text-gray-600 ml-2">An optional name for the participant. Provides the model information to differentiate between participants of the same role.</p>
                        </div>
                      </div>
                      <div className="border-l-2 border-green-200 pl-3">
                        <h4 className="text-sm font-semibold text-black mb-1">User message</h4>
                        <p className="text-xs text-gray-600 mb-2">Messages sent by an end user, containing prompts or additional context information.</p>
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <code className="text-xs font-mono bg-gray-100 px-1 py-0.5 rounded text-black">content</code>
                            <Badge variant="outline" className="text-xs text-black">string or array</Badge>
                            <Badge variant="destructive" className="text-xs">Required</Badge>
                          </div>
                          <p className="text-xs text-gray-600 ml-2">The contents of the user message.</p>
                          <div className="flex items-center space-x-2">
                            <code className="text-xs font-mono bg-gray-100 px-1 py-0.5 rounded text-black">role</code>
                            <Badge variant="outline" className="text-xs text-black">string</Badge>
                            <Badge variant="destructive" className="text-xs">Required</Badge>
                          </div>
                          <p className="text-xs text-gray-600 ml-2">The role of the messages author, in this case user.</p>
                          <div className="flex items-center space-x-2">
                            <code className="text-xs font-mono bg-gray-100 px-1 py-0.5 rounded text-black">name</code>
                            <Badge variant="outline" className="text-xs text-black">string</Badge>
                            <Badge variant="secondary" className="text-xs">Optional</Badge>
                          </div>
                          <p className="text-xs text-gray-600 ml-2">An optional name for the participant. Provides the model information to differentiate between participants of the same role.</p>
                        </div>
                      </div>
                      <div className="border-l-2 border-purple-200 pl-3">
                        <h4 className="text-sm font-semibold text-black mb-1">Assistant message</h4>
                        <p className="text-xs text-gray-600 mb-2">Messages sent by the model in response to user messages.</p>
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <code className="text-xs font-mono bg-gray-100 px-1 py-0.5 rounded text-black">role</code>
                            <Badge variant="outline" className="text-xs text-black">string</Badge>
                            <Badge variant="destructive" className="text-xs">Required</Badge>
                          </div>
                          <p className="text-xs text-gray-600 ml-2">The role of the messages author, in this case assistant.</p>
                          <div className="flex items-center space-x-2">
                            <code className="text-xs font-mono bg-gray-100 px-1 py-0.5 rounded text-black">audio</code>
                            <Badge variant="outline" className="text-xs text-black">object</Badge>
                            <Badge variant="secondary" className="text-xs">Optional</Badge>
                          </div>
                          <p className="text-xs text-gray-600 ml-2">Data about a previous audio response from the model.</p>
                          <div className="flex items-center space-x-2">
                            <code className="text-xs font-mono bg-gray-100 px-1 py-0.5 rounded text-black">content</code>
                            <Badge variant="outline" className="text-xs text-black">string or array</Badge>
                            <Badge variant="secondary" className="text-xs">Optional</Badge>
                          </div>
                          <p className="text-xs text-gray-600 ml-2">The contents of the assistant message. Required unless tool_calls or function_call is specified.</p>
                          <div className="flex items-center space-x-2">
                            <code className="text-xs font-mono bg-gray-100 px-1 py-0.5 rounded text-black">name</code>
                            <Badge variant="outline" className="text-xs text-black">string</Badge>
                            <Badge variant="secondary" className="text-xs">Optional</Badge>
                          </div>
                          <p className="text-xs text-gray-600 ml-2">An optional name for the participant. Provides the model information to differentiate between participants of the same role.</p>
                          <div className="flex items-center space-x-2">
                            <code className="text-xs font-mono bg-gray-100 px-1 py-0.5 rounded text-black">refusal</code>
                            <Badge variant="outline" className="text-xs text-black">string</Badge>
                            <Badge variant="secondary" className="text-xs">Optional</Badge>
                          </div>
                          <p className="text-xs text-gray-600 ml-2">The refusal message by the assistant.</p>
                          <div className="flex items-center space-x-2">
                            <code className="text-xs font-mono bg-gray-100 px-1 py-0.5 rounded text-black">tool_calls</code>
                            <Badge variant="outline" className="text-xs text-black">array</Badge>
                            <Badge variant="secondary" className="text-xs">Optional</Badge>
                          </div>
                          <p className="text-xs text-gray-600 ml-2">The tool calls generated by the model, such as function calls.</p>
                        </div>
                      </div>
                      <div className="border-l-2 border-orange-200 pl-3">
                        <h4 className="text-sm font-semibold text-black mb-1">System message</h4>
                        <p className="text-xs text-gray-600 mb-2">System-level instructions that the model should follow, regardless of messages sent by the user. For newer models, consider using developer messages instead.</p>
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <code className="text-xs font-mono bg-gray-100 px-1 py-0.5 rounded text-black">content</code>
                            <Badge variant="outline" className="text-xs text-black">string or array</Badge>
                            <Badge variant="destructive" className="text-xs">Required</Badge>
                          </div>
                          <p className="text-xs text-gray-600 ml-2">The contents of the system message.</p>
                          <div className="flex items-center space-x-2">
                            <code className="text-xs font-mono bg-gray-100 px-1 py-0.5 rounded text-black">role</code>
                            <Badge variant="outline" className="text-xs text-black">string</Badge>
                            <Badge variant="destructive" className="text-xs">Required</Badge>
                          </div>
                          <p className="text-xs text-gray-600 ml-2">The role of the messages author, in this case system.</p>
                          <div className="flex items-center space-x-2">
                            <code className="text-xs font-mono bg-gray-100 px-1 py-0.5 rounded text-black">name</code>
                            <Badge variant="outline" className="text-xs text-black">string</Badge>
                            <Badge variant="secondary" className="text-xs">Optional</Badge>
                          </div>
                          <p className="text-xs text-gray-600 ml-2">An optional name for the participant. Provides the model information to differentiate between participants of the same role.</p>
                        </div>
                      </div>
                      <div className="border-l-2 border-red-200 pl-3">
                        <h4 className="text-sm font-semibold text-black mb-1">Tool message</h4>
                        <p className="text-xs text-gray-600 mb-2">Messages sent by tools in response to tool calls from the model.</p>
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <code className="text-xs font-mono bg-gray-100 px-1 py-0.5 rounded text-black">content</code>
                            <Badge variant="outline" className="text-xs text-black">string or array</Badge>
                            <Badge variant="destructive" className="text-xs">Required</Badge>
                          </div>
                          <p className="text-xs text-gray-600 ml-2">The contents of the tool message.</p>
                          <div className="flex items-center space-x-2">
                            <code className="text-xs font-mono bg-gray-100 px-1 py-0.5 rounded text-black">role</code>
                            <Badge variant="outline" className="text-xs text-black">string</Badge>
                            <Badge variant="destructive" className="text-xs">Required</Badge>
                          </div>
                          <p className="text-xs text-gray-600 ml-2">The role of the messages author, in this case tool.</p>
                          <div className="flex items-center space-x-2">
                            <code className="text-xs font-mono bg-gray-100 px-1 py-0.5 rounded text-black">tool_call_id</code>
                            <Badge variant="outline" className="text-xs text-black">string</Badge>
                            <Badge variant="destructive" className="text-xs">Required</Badge>
                          </div>
                          <p className="text-xs text-gray-600 ml-2">Tool call that this message is responding to.</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">model</code>
                        <Badge variant="outline" className="text-xs text-black">
                          string
                        </Badge>
                        <Badge variant="destructive" className="text-xs">
                          Required
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      Model ID used to generate the response. Available models include{" "}
                      <code className="text-xs bg-gray-100 px-1 py-0.5 rounded text-black">claude-sonnet-4</code> (Claude Sonnet 4),{" "}
                      <code className="text-xs bg-gray-100 px-1 py-0.5 rounded text-black">gemini-2.5-flash-lite</code> (Gemini 2.5 Flash Lite),{" "}
                      <code className="text-xs bg-gray-100 px-1 py-0.5 rounded text-black">gemini-2.5-pro</code> (Gemini 2.5 Pro), and{" "}
                      <code className="text-xs bg-gray-100 px-1 py-0.5 rounded text-black">gpt-4o-mini</code> (GPT-4o Mini). Each model has different capabilities, performance characteristics, and price points.
                    </p>
                  </div>

                  <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">temperature</code>
                        <Badge variant="outline" className="text-xs text-black">
                          number
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      What sampling temperature to use, between 0 and 2. Higher values like 0.8 will make the output more
                      random, while lower values like 0.2 will make it more focused and deterministic. We generally recommend altering this or top_p but not both.
                    </p>
                    <p className="text-xs text-gray-500">Defaults to 1</p>
                  </div>

                  <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">max_completion_tokens</code>
                        <Badge variant="outline" className="text-xs text-black">
                          integer
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      An upper bound for the number of tokens that can be generated for a completion, including visible output tokens and reasoning tokens.
                    </p>
                  </div>

                  {/* TEMPORARILY HIDDEN - stream parameter */}
                  {/* <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">stream</code>
                        <Badge variant="outline" className="text-xs text-black">
                          boolean
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      If set to true, the model response data will be streamed to the client as it is generated using server-sent events. See the Streaming section below for more information, along with the streaming responses guide for more information on how to handle the streaming events.
                    </p>
                    <p className="text-xs text-gray-500">Defaults to false</p>
                  </div> */}

                  <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">tools</code>
                        <Badge variant="outline" className="text-xs text-black">
                          array
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      A list of tools the model may call. You can provide either custom tools or function tools.
                    </p>
                  </div>

                  <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">response_format</code>
                        <Badge variant="outline" className="text-xs text-black">
                          string
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      The format in which the model output should be returned. Currently only supports string format.
                    </p>
                    {/* TEMPORARILY HIDDEN - Original description for JSON support */}
                    {/* <p className="text-sm text-black mb-2">
                      An object specifying the format that the model must output. Setting to &#123; "type": "json_schema", "json_schema": &#123;...&#125; &#125; enables Structured Outputs which ensures the model will match your supplied JSON schema. Learn more in the Structured Outputs guide.
                    </p> */}
                  </div>

                  <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">service_tier</code>
                        <Badge variant="outline" className="text-xs text-black">
                          string
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      Specifies the processing type used for serving the request. If set to 'auto', then the request will be processed with the service tier configured in the Project settings. Unless otherwise configured, the Project will use 'default'. If set to 'default', then the request will be processed with the standard pricing and performance for the selected model. If set to 'flex' or 'priority', then the request will be processed with the corresponding service tier. When not set, the default behavior is 'auto'. When the service_tier parameter is set, the response body will include the service_tier value based on the processing mode actually used to serve the request. This response value may be different from the value set in the parameter.
                    </p>
                    <p className="text-xs text-gray-500">Defaults to auto</p>
                  </div>

                  {/* TEMPORARILY HIDDEN - audio parameter */}
                  {/* <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">audio</code>
                        <Badge variant="outline" className="text-xs text-black">
                          object or null
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      Parameters for audio output. Required when audio output is requested with modalities: ["audio"]. Learn more.
                    </p>
                  </div> */}

                  <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">frequency_penalty</code>
                        <Badge variant="outline" className="text-xs text-black">
                          number or null
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      Number between -2.0 and 2.0. Positive values penalize new tokens based on their existing frequency in the text so far, decreasing the model's likelihood to repeat the same line verbatim.
                    </p>
                    <p className="text-xs text-gray-500">Defaults to 0</p>
                  </div>

                  {/* TEMPORARILY HIDDEN - logit_bias parameter */}
                  {/* <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">logit_bias</code>
                        <Badge variant="outline" className="text-xs text-black">
                          map
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      Modify the likelihood of specified tokens appearing in the completion. Accepts a JSON object that maps tokens (specified by their token ID in the tokenizer) to an associated bias value from -100 to 100. Mathematically, the bias is added to the logits generated by the model prior to sampling. The exact effect will vary per model, but values between -1 and 1 should decrease or increase likelihood of selection; values like -100 or 100 should result in a ban or exclusive selection of the relevant token.
                    </p>
                    <p className="text-xs text-gray-500">Defaults to null</p>
                  </div> */}

                  <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">logprobs</code>
                        <Badge variant="outline" className="text-xs text-black">
                          boolean or null
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      Whether to return log probabilities of the output tokens or not. If true, returns the log probabilities of each output token returned in the content of message.
                    </p>
                    <p className="text-xs text-gray-500">Defaults to false</p>
                  </div>

                  {/* TEMPORARILY HIDDEN - metadata parameter */}
                  {/* <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">metadata</code>
                        <Badge variant="outline" className="text-xs text-black">
                          map
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      Set of 16 key-value pairs that can be attached to an object. This can be useful for storing additional information about the object in a structured format, and querying for objects via API or the dashboard. Keys are strings with a maximum length of 64 characters. Values are strings with a maximum length of 512 characters.
                    </p>
                  </div> */}

                  {/* TEMPORARILY HIDDEN - modalities parameter */}
                  {/* <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">modalities</code>
                        <Badge variant="outline" className="text-xs text-black">
                          array
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      Output types that you would like the model to generate. Most models are capable of generating text, which is the default: ["text"]. Some models may support additional output types.
                    </p>
                  </div> */}

                  <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">n</code>
                        <Badge variant="outline" className="text-xs text-black">
                          integer or null
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      How many chat completion choices to generate for each input message. Note that you will be charged based on the number of generated tokens across all of the choices. Keep n as 1 to minimize costs.
                    </p>
                    <p className="text-xs text-gray-500">Defaults to 1</p>
                  </div>

                  {/* TEMPORARILY HIDDEN - parallel_tool_calls parameter */}
                  {/* <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">parallel_tool_calls</code>
                        <Badge variant="outline" className="text-xs text-black">
                          boolean
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      Whether to enable parallel function calling during tool use.
                    </p>
                    <p className="text-xs text-gray-500">Defaults to true</p>
                  </div> */}

                  {/* TEMPORARILY HIDDEN - prediction parameter */}
                  {/* <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">prediction</code>
                        <Badge variant="outline" className="text-xs text-black">
                          object
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      Configuration for a Predicted Output, which can greatly improve response times when large parts of the model response are known ahead of time. This is most common when you are regenerating a file with only minor changes to most of the content.
                    </p>
                  </div> */}

                  <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">presence_penalty</code>
                        <Badge variant="outline" className="text-xs text-black">
                          number or null
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      Number between -2.0 and 2.0. Positive values penalize new tokens based on whether they appear in the text so far, increasing the model's likelihood to talk about new topics.
                    </p>
                    <p className="text-xs text-gray-500">Defaults to 0</p>
                  </div>

                  <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">prompt_cache_key</code>
                        <Badge variant="outline" className="text-xs text-black">
                          string
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      Used by OpenAI to cache responses for similar requests to optimize your cache hit rates. Replaces the user field.
                    </p>
                  </div>

                  {/* TEMPORARILY HIDDEN - reasoning_effort parameter */}
                  {/* <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">reasoning_effort</code>
                        <Badge variant="outline" className="text-xs text-black">
                          string
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      Constrains effort on reasoning for supported models. Currently supported values are minimal, low, medium, and high. Reducing reasoning effort can result in faster responses and fewer tokens used on reasoning in a response.
                    </p>
                    <p className="text-xs text-gray-500">Defaults to medium</p>
                  </div> */}

                  <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">safety_identifier</code>
                        <Badge variant="outline" className="text-xs text-black">
                          string
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      A stable identifier used to help detect users of your application that may be violating OpenAI's usage policies. The IDs should be a string that uniquely identifies each user. We recommend hashing their username or email address, in order to avoid sending us any identifying information.
                    </p>
                  </div>

                  <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">stop</code>
                        <Badge variant="outline" className="text-xs text-black">
                          string / array / null
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      Up to 4 sequences where the API will stop generating further tokens. The returned text will not contain the stop sequence.
                    </p>
                    <p className="text-xs text-gray-500">Defaults to null</p>
                  </div>

                  <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">store</code>
                        <Badge variant="outline" className="text-xs text-black">
                          boolean or null
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      Whether or not to store the output of this chat completion request for use in our model distillation or evals products. Supports text and image inputs. Note: image inputs over 8MB will be dropped.
                    </p>
                    <p className="text-xs text-gray-500">Defaults to false</p>
                  </div>

                  {/* TEMPORARILY HIDDEN - stream_options parameter */}
                  {/* <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">stream_options</code>
                        <Badge variant="outline" className="text-xs text-black">
                          object
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      Options for streaming response. Only set this when you set stream: true.
                    </p>
                    <p className="text-xs text-gray-500">Defaults to null</p>
                  </div> */}

                  {/* TEMPORARILY HIDDEN - tool_choice parameter */}
                  {/* <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">tool_choice</code>
                        <Badge variant="outline" className="text-xs text-black">
                          string or object
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      Controls which (if any) tool is called by the model. none means the model will not call any tool and instead generates a message. auto means the model can pick between generating a message or calling one or more tools. required means the model must call one or more tools. Specifying a particular tool via {"{"} "type": "function", "function": {"{"} "name": "my_function" {"}"} {"}"} forces the model to call that tool. none is the default when no tools are present. auto is the default if tools are present.
                    </p>
                  </div> */}

                  <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">top_logprobs</code>
                        <Badge variant="outline" className="text-xs text-black">
                          integer
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      An integer between 0 and 20 specifying the number of most likely tokens to return at each token position, each with an associated log probability.
                    </p>
                  </div>

                  <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">top_p</code>
                        <Badge variant="outline" className="text-xs text-black">
                          number
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      An alternative to sampling with temperature, called nucleus sampling, where the model considers the results of the tokens with top_p probability mass. So 0.1 means only the tokens comprising the top 10% probability mass are considered. We generally recommend altering this or temperature but not both.
                    </p>
                    <p className="text-xs text-gray-500">Defaults to 1</p>
                  </div>

                  {/* TEMPORARILY HIDDEN - verbosity parameter */}
                  {/* <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">verbosity</code>
                        <Badge variant="outline" className="text-xs text-black">
                          string
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      Constrains the verbosity of the model's response. Lower values will result in more concise responses, while higher values will result in more verbose responses. Currently supported values are low, medium, and high.
                    </p>
                    <p className="text-xs text-gray-500">Defaults to medium</p>
                  </div> */}

                  {/* TEMPORARILY HIDDEN - web_search_options parameter */}
                  {/* <div className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm font-mono text-black">web_search_options</code>
                        <Badge variant="outline" className="text-xs text-black">
                          object
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Optional
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-black mb-2">
                      This tool searches the web for relevant results to use in a response. Learn more about the web search tool.
                    </p>
                  </div> */}
                </div>
              )}
            </div>
          </div>

          <div>
            <h2 className="text-lg md:text-xl font-semibold text-black mb-4">Error codes</h2>

            <div className="space-y-4">
              <div className="border border-gray-200 rounded-lg p-4 bg-white">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <code className="text-sm font-mono text-black">400</code>
                    <Badge variant="outline" className="text-xs text-black">
                      Bad Request
                    </Badge>
                  </div>
                </div>
                <p className="text-sm text-black mb-2">
                  The request was malformed or missing required parameters. Check your request body and ensure all
                  required fields are provided with valid values.
                </p>
                <p className="text-xs text-gray-500">
                  Common causes: Invalid JSON, missing required fields, invalid parameter values
                </p>
              </div>

              <div className="border border-gray-200 rounded-lg p-4 bg-white">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <code className="text-sm font-mono text-black">401</code>
                    <Badge variant="outline" className="text-xs text-black">
                      Unauthorized
                    </Badge>
                  </div>
                </div>
                <p className="text-sm text-black mb-2">
                  Authentication failed. Your API key is either missing, invalid, or expired. Ensure you're including a
                  valid API key in the Authorization header.
                </p>
                <p className="text-xs text-gray-500">
                  Check your API key and ensure it's properly formatted: Bearer YOUR_API_KEY
                </p>
              </div>

              <div className="border border-gray-200 rounded-lg p-4 bg-white">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <code className="text-sm font-mono text-black">403</code>
                    <Badge variant="outline" className="text-xs text-black">
                      Forbidden
                    </Badge>
                  </div>
                </div>
                <p className="text-sm text-black mb-2">
                  You don't have permission to access this resource. This may be due to insufficient account permissions
                  or trying to access a restricted model.
                </p>
                <p className="text-xs text-gray-500">
                  Contact support if you believe you should have access to this resource
                </p>
              </div>

              <div className="border border-gray-200 rounded-lg p-4 bg-white">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <code className="text-sm font-mono text-black">429</code>
                    <Badge variant="outline" className="text-xs text-black">
                      Rate Limited
                    </Badge>
                  </div>
                </div>
                <p className="text-sm text-black mb-2">
                  You've exceeded your rate limit. Please wait before making additional requests or consider upgrading
                  your plan for higher limits.
                </p>
                <p className="text-xs text-gray-500">
                  Rate limits reset every minute. Check the Retry-After header for wait time
                </p>
              </div>

              <div className="border border-gray-200 rounded-lg p-4 bg-white">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <code className="text-sm font-mono text-black">500</code>
                    <Badge variant="outline" className="text-xs text-black">
                      Internal Server Error
                    </Badge>
                  </div>
                </div>
                <p className="text-sm text-black mb-2">
                  An unexpected error occurred on our servers. Please try again later. If the problem persists, contact
                  our support team.
                </p>
                <p className="text-xs text-gray-500">Our team is automatically notified of server errors</p>
              </div>

              <div className="border border-gray-200 rounded-lg p-4 bg-white">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <code className="text-sm font-mono text-black">503</code>
                    <Badge variant="outline" className="text-xs text-black">
                      Service Unavailable
                    </Badge>
                  </div>
                </div>
                <p className="text-sm text-black mb-2">
                  The service is temporarily unavailable due to maintenance or high load. Please try again in a few
                  moments.
                </p>
                <p className="text-xs text-gray-500">Check our status page for current service status</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      {searchOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-start justify-center pt-20">
          <div ref={searchModalRef} className="bg-white rounded-lg shadow-xl w-full max-w-2xl mx-4">
            <div className="p-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
                <input
                  type="search"
                  placeholder="Search documentation..."
                  className="w-full rounded-md bg-white border-2 border-[#e81e5a] pl-10 pr-4 py-3 text-sm text-gray-900 placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-[#e81e5a] focus:border-[#e81e5a]"
                  autoFocus
                />
              </div>
              <div className="mt-4 text-xs text-gray-500 flex justify-between">
                <span>Press ESC to close</span>
                <span>Ctrl+K to search</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {toast.visible && (
        <div className="fixed top-20 right-2 md:right-4 z-[9999] bg-black text-white px-3 md:px-4 py-2 md:py-3 rounded-lg shadow-lg min-w-[200px] md:min-w-[250px] max-w-[calc(100vw-1rem)]">
          <div className="flex items-center space-x-2">
            {toast.type === "success" ? (
              <Check className="h-4 w-4 text-green-400" />
            ) : (
              <XCircle className="h-4 w-4 text-red-400" />
            )}
            <span className={toast.type === "success" ? "text-green-400" : "text-red-400"}>{toast.message}</span>
          </div>
        </div>
      )}

      <header className="sticky top-0 z-50 border-b border-gray-200 bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
        <div className="flex h-16 items-center px-4">
          <Button
            variant="ghost"
            size="sm"
            className="mr-2 md:hidden hover:text-[#e81e5a] hover:bg-white"
            onClick={() => setSidebarOpen(!sidebarOpen)}
          >
            <Menu className="h-4 w-4" />
          </Button>

          <div className="flex items-center space-x-2 md:space-x-4">
            <div className="flex items-center space-x-1 md:space-x-2">
              <img
                src="https://portal.ideamart.io/cas/ideamart-custom-styles/images/company-logo-large.png"
                alt="Ideamart Logo"
                className="h-6 md:h-8 w-auto"
              />
              <span className="font-bold text-base md:text-xl text-gray-900 font-[family-name:var(--font-comfortaa)]">
                Omni AI Swagger
              </span>
            </div>
          </div>

          <div className="ml-auto flex items-center space-x-2 md:space-x-4">
            <div
              className="flex items-center space-x-2 bg-gray-50 border border-gray-200 rounded-md px-3 py-2 cursor-pointer hover:border-[#e81e5a] transition-colors"
              onClick={() => setSearchOpen(true)}
            >
              <Search className="h-4 w-4 text-gray-500" />
              <span className="text-sm text-gray-500 hidden sm:inline">Search docs...</span>
              <kbd className="hidden lg:inline-flex items-center px-1.5 py-0.5 text-xs font-mono bg-white border border-gray-200 rounded text-black">
                CTRL + K
              </kbd>
            </div>
            <div className="flex items-center space-x-1 md:space-x-2">
              <Button
                size="sm"
                className="bg-[#e81e5a] text-white hover:bg-[#d01850] font-semibold text-xs md:text-sm shadow-lg transition-all duration-200 px-2 md:px-4"
                onClick={() => window.open("https://omniai.ideamart.io/", "_blank")}
              >
                <span className="hidden sm:inline">Go to </span>Portal
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Mobile sidebar backdrop */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 z-30 bg-black/50 md:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}
        
        <aside
          className={`${sidebarOpen ? "translate-x-0" : "-translate-x-full"} fixed inset-y-0 left-0 z-40 w-64 sm:w-72 transform bg-white border-r border-gray-200 shadow-lg transition-transform duration-200 ease-in-out md:relative md:translate-x-0`}
        >
          <div className="flex h-full flex-col">
            <ScrollArea className="flex-1 px-4 py-6">
              <div className="space-y-1">
                <div className="mb-6">
                  {sidebarItems.map((item) => (
                    <Button
                      key={item.label}
                      variant="ghost"
                      className={`w-full justify-start text-sm py-3 px-3 rounded-lg transition-all duration-200 ${activeTab === item.id
                        ? "bg-[#e81e5a]/10 text-[#e81e5a] font-semibold border-l-4 border-[#e81e5a] shadow-sm"
                        : "text-gray-700 hover:bg-gray-50 hover:text-[#e81e5a] border-l-4 border-transparent"
                        }`}
                      size="sm"
                      onClick={() => {
                        setActiveTab(item.id)
                        setSidebarOpen(false)
                      }}
                    >
                      <div className="flex items-center space-x-3">
                        {item.icon && <item.icon className="h-4 w-4" />}
                        <span>{item.label}</span>
                      </div>
                    </Button>
                  ))}
                </div>
              </div>

              <div className="mt-8">
                <div className="flex items-center justify-between px-3 mb-4">
                  <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">API Reference</h3>
                  <div className="h-px bg-gray-200 flex-1 ml-3"></div>
                </div>

                <div className="mb-3">
                  <div className="ml-4 space-y-0">
                    {endpoints
                      .filter((e) => e.category === "Chat")
                      .map((endpoint) => (
                        <Button
                          key={endpoint.id}
                          variant="ghost"
                          className={`w-full justify-start text-sm py-1 px-3 rounded-md transition-all duration-200 ${selectedEndpoint === endpoint.id && activeTab === "api-reference"
                            ? "bg-[#e81e5a]/10 text-[#e81e5a] font-semibold border-l-3 border-[#e81e5a]"
                            : "text-gray-600 hover:bg-gray-50 hover:text-[#e81e5a] border-l-3 border-transparent"
                            }`}
                          size="sm"
                          onClick={() => {
                            setSelectedEndpoint(endpoint.id)
                            setActiveTab("api-reference")
                            setSidebarOpen(false)
                          }}
                        >
                          <div className="flex items-center justify-between w-full">
                            <span className="truncate">{endpoint.title}</span>
                            <Badge
                              variant="outline"
                              className="text-xs ml-2 bg-green-50 text-green-700 border-green-200"
                            >
                              {endpoint.method}
                            </Badge>
                          </div>
                        </Button>
                      ))}
                  </div>
                </div>

                <div className="mb-3">
                  <div className="ml-4 space-y-0">
                    {endpoints
                      .filter((e) => e.category === "Images")
                      .map((endpoint) => (
                        <Button
                          key={endpoint.id}
                          variant="ghost"
                          className={`w-full justify-start text-sm py-1 px-3 rounded-md transition-all duration-200 ${selectedEndpoint === endpoint.id && activeTab === "api-reference"
                            ? "bg-[#e81e5a]/10 text-[#e81e5a] font-semibold border-l-3 border-[#e81e5a]"
                            : "text-gray-600 hover:bg-gray-50 hover:text-[#e81e5a] border-l-3 border-transparent"
                            }`}
                          size="sm"
                          onClick={() => {
                            setSelectedEndpoint(endpoint.id)
                            setActiveTab("api-reference")
                            setSidebarOpen(false)
                          }}
                        >
                          <div className="flex items-center justify-between w-full">
                            <span className="truncate">{endpoint.title}</span>
                            <Badge
                              variant="outline"
                              className="text-xs ml-2 bg-purple-50 text-purple-700 border-purple-200"
                            >
                              {endpoint.method}
                            </Badge>
                          </div>
                        </Button>
                      ))}
                  </div>
                </div>

                <div className="mb-3">
                  <div className="ml-4 space-y-0">
                    {endpoints
                      .filter((e) => e.category === "Reference")
                      .map((endpoint) => (
                        <Button
                          key={endpoint.id}
                          variant="ghost"
                          className={`w-full justify-start text-sm py-1 px-3 rounded-md transition-all duration-200 ${selectedEndpoint === endpoint.id && activeTab === "api-reference"
                            ? "bg-[#e81e5a]/10 text-[#e81e5a] font-semibold border-l-3 border-[#e81e5a]"
                            : "text-gray-600 hover:bg-gray-50 hover:text-[#e81e5a] border-l-3 border-transparent"
                            }`}
                          size="sm"
                          onClick={() => {
                            setSelectedEndpoint(endpoint.id)
                            setActiveTab("api-reference")
                            setSidebarOpen(false)
                          }}
                        >
                          <div className="flex items-center justify-between w-full">
                            <span className="truncate">{endpoint.title}</span>
                            <Badge variant="outline" className="text-xs ml-2 bg-blue-50 text-blue-700 border-blue-200">
                              REF
                            </Badge>
                          </div>
                        </Button>
                      ))}
                  </div>
                </div>
              </div>
            </ScrollArea>
          </div>
        </aside>

        <main className="flex-1 min-w-0 overflow-x-hidden w-full max-w-full">
          {activeTab === "overview" ? (
            <div className="min-h-screen">
              <ScrollArea className="h-screen">{renderContent()}</ScrollArea>
            </div>
          ) : selectedEndpoint === "error-codes" ? (
            <div className="min-h-screen">
              <ScrollArea className="h-screen">{renderContent()}</ScrollArea>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 min-h-screen w-full max-w-full overflow-x-hidden">
              <div className="border-r border-gray-200 min-w-0 overflow-x-hidden">
                <ScrollArea className="h-screen">{renderContent()}</ScrollArea>
              </div>

              <div className="bg-gray-50 overflow-x-hidden min-w-0 w-full max-w-full">
                <ScrollArea className="h-screen w-full">
                  <div className="p-3 sm:p-4 md:p-6 space-y-4 sm:space-y-6 overflow-x-hidden w-full max-w-full box-border">
                    <div className="bg-white border border-gray-200 rounded-lg p-2 sm:p-3 md:p-4 w-full max-w-full box-border">
                      <div className="flex items-center justify-between gap-1 sm:gap-2 w-full min-w-0">
                        <div className="flex items-center gap-1 sm:gap-2 flex-1 min-w-0 overflow-hidden">
                          <Badge variant="secondary" className="text-xs font-mono flex-shrink-0">
                            {currentEndpoint?.method}
                          </Badge>
                          <code className="text-xs sm:text-sm font-mono text-black truncate min-w-0 flex-1">
                            {selectedEndpoint === "chat-completion" 
                              ? "https://api.ideamart.io/omniai/api/v1/chat/completions"
                              : selectedEndpoint === "create-image"
                              ? "https://api.ideamart.io/omniai/api/v1/images/generations"
                              : `https://api.ideamart.io${currentEndpoint?.path}`}
                          </code>
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="ml-1 sm:ml-2 flex-shrink-0 hover:text-[#e81e5a] hover:bg-white z-10 p-1.5 sm:p-2"
                          onClick={() => copyToClipboard(
                            selectedEndpoint === "chat-completion" 
                              ? "https://api.ideamart.io/omniai/api/v1/chat/completions"
                              : selectedEndpoint === "create-image"
                              ? "https://api.ideamart.io/omniai/api/v1/images/generations"
                              : `https://api.ideamart.io${currentEndpoint?.path}`,
                            "Endpoint"
                          )}
                        >
                          <Copy className="h-3.5 w-3.5 sm:h-4 sm:w-4 text-black" />
                        </Button>
                      </div>
                    </div>

                    <div className="border-b border-gray-200 pb-3 sm:pb-4 w-full max-w-full box-border">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 sm:gap-3 md:gap-4 w-full">
                        <h3 className="text-sm sm:text-base md:text-lg font-semibold text-black flex-shrink-0 whitespace-nowrap">Request</h3>
                        <div className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0 w-full sm:w-auto">
                          <Button
                            variant="ghost"
                            size="sm"
                            className={`text-black bg-white hover:text-[#e81e5a] hover:bg-white border border-gray-200 text-xs sm:text-sm px-2 sm:px-3 md:px-4 py-1.5 whitespace-nowrap flex-shrink-0 flex-1 sm:flex-none ${selectedLanguage === "curl"
                              ? "border-2 border-[#e81e5a] bg-transparent font-bold text-[#e81e5a]"
                              : ""
                              }`}
                            onClick={() => setSelectedLanguage("curl")}
                          >
                            cURL
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className={`text-black bg-white hover:text-[#e81e5a] hover:bg-white border border-gray-200 text-xs sm:text-sm px-2 sm:px-3 md:px-4 py-1.5 whitespace-nowrap flex-shrink-0 flex-1 sm:flex-none ${selectedLanguage === "python"
                              ? "border-2 border-[#e81e5a] bg-transparent font-bold text-[#e81e5a]"
                              : ""
                              }`}
                            onClick={() => setSelectedLanguage("python")}
                          >
                            Python
                          </Button>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4 w-full max-w-full box-border">
                      <div className="relative w-full max-w-full box-border">
                        <Button
                          size="sm"
                          variant="ghost"
                          className="absolute right-1.5 sm:right-2 top-1.5 sm:top-2 z-20 bg-white hover:text-[#e81e5a] hover:bg-white border border-gray-200 shadow-sm p-1.5 sm:p-2"
                          onClick={() => copyToClipboard(getCodeExample(selectedLanguage), "Request code")}
                        >
                          <Copy className="h-3.5 w-3.5 sm:h-4 sm:w-4 text-black" />
                        </Button>
                        <pre className="bg-white border border-gray-200 p-2 sm:p-3 md:p-4 rounded-lg text-xs sm:text-sm font-mono overflow-x-auto w-full max-w-full box-border">
                          <code className="text-black break-words whitespace-pre-wrap">{getCodeExample(selectedLanguage)}</code>
                        </pre>
                      </div>
                    </div>

                    <div className="border-t border-gray-200 pt-4 sm:pt-6 w-full max-w-full box-border">
                      <h3 className="text-sm sm:text-base md:text-lg font-semibold text-black mb-3 sm:mb-4">Response</h3>
                      <div className="relative w-full max-w-full box-border">
                        <Button
                          size="sm"
                          variant="ghost"
                          className="absolute right-1.5 sm:right-2 top-1.5 sm:top-2 z-20 bg-white hover:text-[#e81e5a] hover:bg-white border border-gray-200 shadow-sm p-1.5 sm:p-2"
                          onClick={() => copyToClipboard(getResponseExample(selectedLanguage), "Response code")}
                        >
                          <Copy className="h-3.5 w-3.5 sm:h-4 sm:w-4 text-black" />
                        </Button>
                        <pre className="bg-white border border-gray-200 p-2 sm:p-3 md:p-4 rounded-lg text-xs sm:text-sm font-mono overflow-x-auto w-full max-w-full box-border">
                          <code className="text-black break-words whitespace-pre-wrap">{getResponseExample(selectedLanguage)}</code>
                        </pre>
                      </div>
                    </div>
                  </div>
                </ScrollArea>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  )
}