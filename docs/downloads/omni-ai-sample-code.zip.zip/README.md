# Omni AI Documentation Portal
**Project ID:** `DIA-OMAI-SWG-CODE-V1.0.0`

This repository contains the source code for the Omni AI Documentation project, built using **Next.js 15**, **React 19**, and **Tailwind CSS 4**.

## 🛠 Prerequisites

Before building the project, ensure you have the following installed:
* **Node.js**: version `20.x` or higher (recommended)
* **npm**: (comes with Node.js) or **pnpm** / **yarn**

## 🚀 Getting Started

Follow these steps to get the development environment running:

### 1. Extract the Archive
Unzip the `DIA-OMAI-SWG-CODE-V1.0.0.zip` file into your desired working directory.

### 2. Install Dependencies
Open your terminal in the extracted folder and run:
```bash
npm install
```
*(This will install all necessary packages including Next.js, Radix UI, and Tailwind CSS).*

### 3. Run the Development Server
Start the local server using **Turbopack** for the fastest performance:
```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser to view the result.

---

## 🏗 Building for Production

To create an optimized production build of the documentation:

1. **Build the project:**
   ```bash
   npm run build
   ```
2. **Start the production server:**
   ```bash
   npm run start
   ```

---

## 📂 Project Structure

* `next.config.mjs`: Next.js configuration using the latest ESM standards.
* `tailwind.config.ts`: Styling configurations for Tailwind CSS 4.
* `components/`: Reusable UI components (Radix UI, Lucide icons).
* `app/`: The core application logic using the Next.js App Router.

## 📜 Available Scripts

| Command | Action |
| :--- | :--- |
| `npm run dev` | Runs the app in development mode with Turbopack. |
| `npm run build` | Compiles the application for production deployment. |
| `npm run start` | Starts the production build locally. |
| `npm run lint` | Runs ESLint to check for code quality issues. |

---

> **Note:** This project is set to `private: true`. Ensure that sensitive API keys or environment variables are added to a `.env.local` file (not included in the source distribution) if required for future features.