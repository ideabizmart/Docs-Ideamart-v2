import type React from "react"
import type { Metadata } from "next"
import { Space_Grotesk, DM_Sans, Comfortaa } from "next/font/google"
import "./globals.css"

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-space-grotesk",
})

const dmSans = DM_Sans({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-dm-sans",
})

const comfortaa = Comfortaa({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-comfortaa",
})

export const metadata: Metadata = {
  title: "OmniAI Developer Documentation",
  description: "Comprehensive API documentation and developer resources for OmniAI platform",
  generator: "v0.app",
  icons: {
    icon: "/icon.png",
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="dark">
      <body className={`font-sans ${spaceGrotesk.variable} ${dmSans.variable} ${comfortaa.variable} antialiased`}>
        {children}
      </body>
    </html>
  )
}
